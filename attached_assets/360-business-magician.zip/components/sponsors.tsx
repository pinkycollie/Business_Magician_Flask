import Image from "next/image"
import Link from "next/link"

import { Card, CardContent } from "@/components/ui/card"

export default function Sponsors() {
  const sponsors = [
    {
      name: "Small Business Administration",
      logo: "/placeholder.svg?height=80&width=200",
      url: "https://www.sba.gov/",
    },
    {
      name: "Vocational Rehabilitation",
      logo: "/placeholder.svg?height=80&width=200",
      url: "#",
    },
    {
      name: "Workforce Solutions",
      logo: "/placeholder.svg?height=80&width=200",
      url: "#",
    },
    {
      name: "SCORE Fort Worth",
      logo: "/placeholder.svg?height=80&width=200",
      url: "#",
    },
    {
      name: "Fort Worth Metropolitan Black Chamber of Commerce",
      logo: "/placeholder.svg?height=80&width=200",
      url: "#",
    },
    {
      name: "Texas Deaf Chamber of Commerce",
      logo: "/placeholder.svg?height=80&width=200",
      url: "#",
    },
    {
      name: "Accelerate of Fort Worth Foundation",
      logo: "/placeholder.svg?height=80&width=200",
      url: "#",
    },
  ]

  return (
    <section id="sponsors" className="py-20">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Our Sponsors</h2>
          <p className="text-lg text-muted-foreground">
            360 Business Magician is proudly supported by these organizations committed to empowering deaf individuals
            in business and employment.
          </p>
        </div>

        <div className="relative py-10 overflow-hidden">
          {/* Gradient overlays for carousel effect */}
          <div className="absolute left-0 top-0 bottom-0 w-16 z-10 bg-gradient-to-r from-background to-transparent"></div>
          <div className="absolute right-0 top-0 bottom-0 w-16 z-10 bg-gradient-to-l from-background to-transparent"></div>

          {/* Sponsor logos */}
          <div className="flex items-center justify-around flex-wrap gap-8 md:gap-12">
            {sponsors.map((sponsor, index) => (
              <Link key={index} href={sponsor.url} target="_blank" rel="noopener noreferrer" className="group">
                <Card className="border-none shadow-sm hover:shadow-md transition-shadow bg-transparent">
                  <CardContent className="p-4 flex items-center justify-center h-24">
                    <div className="relative h-16 w-40">
                      <Image
                        src={sponsor.logo || "/placeholder.svg"}
                        alt={`${sponsor.name} logo`}
                        fill
                        className="object-contain filter grayscale group-hover:grayscale-0 transition-all"
                      />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Interested in becoming a sponsor? Contact us to learn about partnership opportunities.
          </p>
        </div>
      </div>
    </section>
  )
}

