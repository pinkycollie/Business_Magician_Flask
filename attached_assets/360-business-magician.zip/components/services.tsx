import {
  Briefcase,
  Bot,
  Building,
  FileText,
  GraduationCap,
  Handshake,
  LayoutDashboard,
  LineChart,
  Users,
} from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Services() {
  const jobSeekerServices = [
    {
      icon: <FileText className="h-10 w-10 text-primary" />,
      title: "AI-Powered Resume Building",
      description: "Create professional resumes with AI assistance tailored for deaf job seekers.",
    },
    {
      icon: <GraduationCap className="h-10 w-10 text-primary" />,
      title: "Skills Training",
      description: "Access specialized training programs with ASL support and VR funding options.",
    },
    {
      icon: <Users className="h-10 w-10 text-primary" />,
      title: "Job Placement",
      description: "Connect with deaf-friendly employers and opportunities matching your skills.",
    },
    {
      icon: <LayoutDashboard className="h-10 w-10 text-primary" />,
      title: "Application Tracking",
      description: "Manage your job applications with our AI-powered tracking dashboard.",
    },
  ]

  const selfEmploymentServices = [
    {
      icon: <Bot className="h-10 w-10 text-primary" />,
      title: "Business Formation",
      description: "Automated LLC creation, EIN registration, and business licensing assistance.",
    },
    {
      icon: <FileText className="h-10 w-10 text-primary" />,
      title: "Business Planning",
      description: "AI-assisted business plan development with ASL support and guidance.",
    },
    {
      icon: <LineChart className="h-10 w-10 text-primary" />,
      title: "Funding Resources",
      description: "Access to VR funding options and other financial resources for entrepreneurs.",
    },
    {
      icon: <GraduationCap className="h-10 w-10 text-primary" />,
      title: "Business Training",
      description: "Self-paced business courses with ASL interpretation and AI assistance.",
    },
  ]

  const smallBusinessServices = [
    {
      icon: <Building className="h-10 w-10 text-primary" />,
      title: "Business Automation",
      description: "AI-powered workflows to streamline your business operations and growth.",
    },
    {
      icon: <Users className="h-10 w-10 text-primary" />,
      title: "Hiring & Workforce",
      description: "Tools for building and managing your team with accessibility in mind.",
    },
    {
      icon: <Handshake className="h-10 w-10 text-primary" />,
      title: "Business Coaching",
      description: "Connect with mentors and coaches experienced in deaf entrepreneurship.",
    },
    {
      icon: <LineChart className="h-10 w-10 text-primary" />,
      title: "Compliance Tracking",
      description: "Automated compliance monitoring and reporting for your business.",
    },
  ]

  return (
    <section id="services" className="py-20 bg-muted/50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Our AI-Powered Services</h2>
          <p className="text-lg text-muted-foreground">
            360 Business Magician provides specialized services for deaf individuals at every stage of their career
            journey.
          </p>
        </div>

        <Tabs defaultValue="job-seekers" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="job-seekers" className="flex items-center gap-2">
              <Briefcase className="h-4 w-4" />
              <span className="hidden sm:inline">Job Seekers</span>
            </TabsTrigger>
            <TabsTrigger value="self-employment" className="flex items-center gap-2">
              <Bot className="h-4 w-4" />
              <span className="hidden sm:inline">Self-Employment</span>
            </TabsTrigger>
            <TabsTrigger value="small-business" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              <span className="hidden sm:inline">Small Business</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="job-seekers">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {jobSeekerServices.map((service, index) => (
                <Card key={index} className="border-none shadow-md hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="mb-2">{service.icon}</div>
                    <CardTitle>{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">{service.description}</CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="self-employment">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {selfEmploymentServices.map((service, index) => (
                <Card key={index} className="border-none shadow-md hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="mb-2">{service.icon}</div>
                    <CardTitle>{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">{service.description}</CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="small-business">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {smallBusinessServices.map((service, index) => (
                <Card key={index} className="border-none shadow-md hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="mb-2">{service.icon}</div>
                    <CardTitle>{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">{service.description}</CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  )
}

