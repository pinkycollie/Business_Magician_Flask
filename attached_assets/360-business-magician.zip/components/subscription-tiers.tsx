import { Bot, Briefcase, Building, Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function SubscriptionTiers() {
  const tiers = [
    {
      icon: <Briefcase className="h-12 w-12 text-primary" />,
      title: "Job Seekers",
      description: "For deaf individuals looking for employment",
      price: "Free (VR Funded)",
      premiumPrice: "$XX/month for premium",
      features: [
        "AI-powered job search & application tracking",
        "Resume optimization & interview prep",
        "Vocational training & skill-building courses",
        "ASL video support & accessibility tools",
      ],
      badge: "Most Popular",
      buttonText: "Get Started",
    },
    {
      icon: <Bot className="h-12 w-12 text-primary" />,
      title: "Self-Employment",
      description: "For deaf entrepreneurs starting a business",
      price: "$XX/month",
      premiumPrice: "VR-funded options available",
      features: [
        "Business formation automation (LLC, EIN, licensing)",
        "AI-powered tax & compliance tracking",
        "Self-paced business training & funding resources",
        "Limited VR support for eligible users",
      ],
      badge: null,
      buttonText: "Start Your Business",
    },
    {
      icon: <Building className="h-12 w-12 text-primary" />,
      title: "Small Business",
      description: "For deaf-owned businesses expanding operations",
      price: "Premium Subscription",
      premiumPrice: "VR Partial Coverage Available",
      features: [
        "Full business automation with AI workflows",
        "Workforce development & hiring tools",
        "Compliance tracking & funding resources",
        'Paywall-based AI automation with "RUN" button',
      ],
      badge: "Advanced",
      buttonText: "Grow Your Business",
    },
  ]

  return (
    <section id="tiers" className="py-20 bg-muted/50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Subscription Tiers</h2>
          <p className="text-lg text-muted-foreground">
            Choose the plan that fits your needs, with VR funding options available for eligible users.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          {tiers.map((tier, index) => (
            <Card key={index} className={`relative border-2 ${index === 0 ? "border-primary" : "border-border"}`}>
              {tier.badge && <Badge className="absolute top-4 right-4 bg-primary">{tier.badge}</Badge>}
              <CardHeader>
                <div className="mb-4">{tier.icon}</div>
                <CardTitle className="text-2xl">{tier.title}</CardTitle>
                <CardDescription className="text-base">{tier.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <p className="text-2xl font-bold">{tier.price}</p>
                  <p className="text-sm text-muted-foreground">{tier.premiumPrice}</p>
                </div>

                <ul className="space-y-2">
                  {tier.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full" variant={index === 0 ? "default" : "outline"}>
                  {tier.buttonText}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

