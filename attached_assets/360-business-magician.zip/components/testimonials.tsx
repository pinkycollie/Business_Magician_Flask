import Image from "next/image"
import { Quote } from "lucide-react"

import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"

export default function Testimonials() {
  const testimonials = [
    {
      quote:
        "As a deaf job seeker, I struggled with traditional job platforms. 360 Business Magician's AI tools and ASL support made the entire process accessible and I found a job within weeks.",
      name: "Michael Johnson",
      role: "Software Developer",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "The business formation automation saved me countless hours. I was able to set up my LLC, get my EIN, and handle all the paperwork with the AI assistant guiding me through each step.",
      name: "Sarah Williams",
      role: "Independent Consultant",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "The VR funding integration was seamless. I was able to get the equipment and training I needed through my vocational rehabilitation counselor while using the platform.",
      name: "David Chen",
      role: "Graphic Designer",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "As a small business owner, the compliance tracking and AI automation tools have been game-changers. I can focus on growing my business instead of paperwork.",
      name: "Emily Rodriguez",
      role: "Boutique Owner",
      image: "/placeholder.svg?height=100&width=100",
    },
  ]

  return (
    <section className="py-20 bg-muted/50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Success Stories</h2>
          <p className="text-lg text-muted-foreground">
            Hear from deaf individuals who have transformed their careers with our AI-powered platform.
          </p>
        </div>

        <Carousel className="w-full max-w-5xl mx-auto">
          <CarouselContent>
            {testimonials.map((testimonial, index) => (
              <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/2">
                <div className="p-2">
                  <Card className="border-none shadow-md h-full">
                    <CardContent className="pt-6">
                      <Quote className="h-8 w-8 text-primary mb-4" />
                      <p className="text-lg italic">{testimonial.quote}</p>
                    </CardContent>
                    <CardFooter>
                      <div className="flex items-center gap-4">
                        <div className="relative w-12 h-12 rounded-full overflow-hidden">
                          <Image
                            src={testimonial.image || "/placeholder.svg"}
                            alt={testimonial.name}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="font-semibold">{testimonial.name}</h4>
                          <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                        </div>
                      </div>
                    </CardFooter>
                  </Card>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div className="flex justify-center mt-8 gap-2">
            <CarouselPrevious className="relative inset-0 translate-y-0" />
            <CarouselNext className="relative inset-0 translate-y-0" />
          </div>
        </Carousel>
      </div>
    </section>
  )
}

