import Image from "next/image"
import { Bot, CuboidIcon as Cube, Globe, HeadphonesIcon, LayoutDashboard, Layers3Icon as Layers3D } from "lucide-react"

export default function Features() {
  return (
    <section id="features" className="py-20">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Platform Features</h2>
          <p className="text-lg text-muted-foreground">
            Our AI-powered platform is designed specifically for deaf users with cutting-edge technology.
          </p>
        </div>

        <div className="grid gap-16">
          {/* Feature 1 */}
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="order-2 md:order-1">
              <div className="inline-flex items-center gap-2 mb-4">
                <Layers3D className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">3D Interactive Interface</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Our platform features a headless CMS with 3D pop-out layers for interactive accessibility, making
                navigation intuitive for deaf users.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <span className="bg-primary/10 text-primary p-1 rounded-full">
                    <Cube className="h-4 w-4" />
                  </span>
                  <span>Interactive 3D elements for intuitive navigation</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="bg-primary/10 text-primary p-1 rounded-full">
                    <Globe className="h-4 w-4" />
                  </span>
                  <span>Fully accessible design optimized for deaf users</span>
                </li>
              </ul>
            </div>
            <div className="order-1 md:order-2 relative h-[300px] rounded-lg overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=300&width=500"
                alt="3D interactive interface demonstration"
                fill
                className="object-cover"
              />
            </div>
          </div>

          {/* Feature 2 */}
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="relative h-[300px] rounded-lg overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=300&width=500"
                alt="ASL support widget demonstration"
                fill
                className="object-cover"
              />
            </div>
            <div>
              <div className="inline-flex items-center gap-2 mb-4">
                <HeadphonesIcon className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">ASL Support Widget</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Our AI-powered ASL support widget provides real-time communication assistance for deaf users navigating
                the platform.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <span className="bg-primary/10 text-primary p-1 rounded-full">
                    <Bot className="h-4 w-4" />
                  </span>
                  <span>AI-powered ASL interpretation and assistance</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="bg-primary/10 text-primary p-1 rounded-full">
                    <LayoutDashboard className="h-4 w-4" />
                  </span>
                  <span>Integrated with all platform features for seamless experience</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Feature 3 */}
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="order-2 md:order-1">
              <div className="inline-flex items-center gap-2 mb-4">
                <LayoutDashboard className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">Integrated Workforce Platform</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Our platform seamlessly integrates with Workforce Centers and provides real-time job market data
                tailored to deaf professionals.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <span className="bg-primary/10 text-primary p-1 rounded-full">
                    <Bot className="h-4 w-4" />
                  </span>
                  <span>Automated geolocation-based task tracking</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="bg-primary/10 text-primary p-1 rounded-full">
                    <Globe className="h-4 w-4" />
                  </span>
                  <span>Resume upload and certification management</span>
                </li>
              </ul>
            </div>
            <div className="order-1 md:order-2 relative h-[300px] rounded-lg overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=300&width=500"
                alt="Integrated workforce platform demonstration"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

