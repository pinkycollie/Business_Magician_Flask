import { LayoutDashboard, Database, Bot, Shield, CreditCard, Video, Code, Globe } from "lucide-react"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function TechStack() {
  const techCategories = [
    {
      id: "frontend",
      icon: <Globe className="h-5 w-5" />,
      name: "Frontend",
      description: "User Interface & Experience",
      color: "bg-green-500",
      technologies: [
        "Component-based UI framework",
        "Static site generation & server-side rendering",
        "CSS utility-first framework for styling",
        "Client-side routing system",
        "Headless authentication system",
        "API client for data fetching",
        "Web animation library",
      ],
    },
    {
      id: "backend",
      icon: <Code className="h-5 w-5" />,
      name: "Backend",
      description: "Data Processing & Business Logic",
      color: "bg-orange-500",
      technologies: [
        "Serverless cloud functions",
        "ORM for database management",
        "Schema migration tool",
        "API gateway & request handling",
        "Caching system",
        "Event-driven task processing",
        "Load balancing & rate limiting",
      ],
    },
    {
      id: "database",
      icon: <Database className="h-5 w-5" />,
      name: "Database & Storage",
      description: "Data Management & Storage Solutions",
      color: "bg-yellow-500",
      technologies: [
        "Serverless relational database",
        "Object storage for files, videos, and documents",
        "Realtime synchronization service",
        "Edge caching & content delivery network",
        "AI-powered query optimization",
      ],
    },
    {
      id: "ai",
      icon: <Bot className="h-5 w-5" />,
      name: "AI & Automation",
      description: "Intelligent Systems & Automation",
      color: "bg-purple-500",
      technologies: [
        "Large language model API",
        "AI-powered document processing",
        "Chatbot framework",
        "AI-based recommendation engine",
        "Speech-to-text and text-to-speech APIs",
        "Automated workflow engine",
      ],
    },
    {
      id: "coaching",
      icon: <Video className="h-5 w-5" />,
      name: "Job Coaching",
      description: "VR Business Management Tools",
      color: "bg-blue-500",
      technologies: [
        "Secure document sharing & collaboration",
        "Real-time presence & co-editing system",
        "Cloud-based video hosting & live streaming",
        "Digital signature & document verification",
        "Virtual meeting & remote coaching system",
      ],
    },
    {
      id: "payments",
      icon: <CreditCard className="h-5 w-5" />,
      name: "Payments",
      description: "Financial Tools & Processing",
      color: "bg-orange-500",
      technologies: [
        "API for handling business transactions",
        "Subscription billing & invoicing",
        "Smart contract & blockchain integration",
        "Automated tax calculation & reporting",
      ],
    },
    {
      id: "security",
      icon: <Shield className="h-5 w-5" />,
      name: "Security",
      description: "Compliance & Data Protection",
      color: "bg-yellow-500",
      technologies: [
        "Identity verification & authentication framework",
        "Data encryption & privacy management",
        "Audit logging & compliance tracking",
        "Multi-factor authentication system",
      ],
    },
    {
      id: "devops",
      icon: <LayoutDashboard className="h-5 w-5" />,
      name: "DevOps",
      description: "Development & Operations",
      color: "bg-purple-500",
      technologies: [
        "Version control & repository hosting",
        "Continuous integration & deployment system",
        "API testing & debugging tools",
        "Infrastructure as code deployment framework",
        "Logging & monitoring dashboard",
      ],
    },
  ]

  return (
    <section id="tech-stack" className="py-20 bg-muted/50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Technical Implementation</h2>
          <p className="text-lg text-muted-foreground">
            Our platform is built with cutting-edge technologies to provide a seamless experience for deaf users.
          </p>
        </div>

        <Tabs defaultValue="frontend" className="w-full">
          <TabsList className="grid grid-cols-4 md:grid-cols-8 mb-8">
            {techCategories.map((category) => (
              <TabsTrigger key={category.id} value={category.id} className="flex flex-col items-center gap-1 py-3">
                <span className={`p-1.5 rounded-full ${category.color.replace("bg-", "bg-opacity-20 text-")}`}>
                  {category.icon}
                </span>
                <span className="text-xs">{category.name}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {techCategories.map((category) => (
            <TabsContent key={category.id} value={category.id}>
              <div className="bg-card rounded-lg p-6 shadow-md">
                <div className="flex items-center gap-3 mb-4">
                  <span className={`p-2 rounded-full ${category.color}`}>{category.icon}</span>
                  <div>
                    <h3 className="text-xl font-semibold">{category.name}</h3>
                    <p className="text-muted-foreground">{category.description}</p>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mt-6">
                  {category.technologies.map((tech, index) => (
                    <div key={index} className="bg-muted/50 p-4 rounded-lg">
                      <p>{tech}</p>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our comprehensive tech stack ensures that 360 Business Magician delivers a powerful, accessible, and secure
            platform for deaf individuals seeking employment and business growth.
          </p>
        </div>
      </div>
    </section>
  )
}

