import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Bot, Briefcase, Building } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function Hero() {
  return (
    <section className="relative py-20 md:py-28 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 left-1/3 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl" />
      </div>

      <div className="container grid gap-8 md:grid-cols-2 md:gap-12 items-center">
        <div className="flex flex-col gap-6">
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="px-3 py-1 border-primary/30 bg-primary/5">
              <Bot className="mr-1 h-3 w-3" /> AI-Powered
            </Badge>
            <Badge variant="outline" className="px-3 py-1 border-primary/30 bg-primary/5">
              ASL-Friendly
            </Badge>
            <Badge variant="outline" className="px-3 py-1 border-primary/30 bg-primary/5">
              VR Funding Compatible
            </Badge>
          </div>

          <div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-4">
              AI-Powered{" "}
              <span className="bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
                Employment & Business
              </span>{" "}
              Platform
            </h1>
            <p className="text-xl text-muted-foreground">
              The first AI-powered platform built specifically for Deaf individuals seeking employment, self-employment,
              and business growth.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-2">
            <div className="flex flex-col items-center p-4 bg-muted/50 rounded-lg">
              <Briefcase className="h-8 w-8 text-primary mb-2" />
              <h3 className="font-medium text-center">Job Seekers</h3>
            </div>
            <div className="flex flex-col items-center p-4 bg-muted/50 rounded-lg">
              <Bot className="h-8 w-8 text-primary mb-2" />
              <h3 className="font-medium text-center">Self-Employment</h3>
            </div>
            <div className="flex flex-col items-center p-4 bg-muted/50 rounded-lg">
              <Building className="h-8 w-8 text-primary mb-2" />
              <h3 className="font-medium text-center">Small Business</h3>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" asChild>
              <Link href="#tiers">
                Explore Subscription Tiers <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="#funding">VR Funding Info</Link>
            </Button>
          </div>
        </div>

        <div className="relative h-[400px] md:h-[500px] rounded-lg overflow-hidden shadow-xl">
          <Image
            src="/placeholder.svg?height=500&width=600"
            alt="360 Business Magician platform interface showing AI assistant and ASL support"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
            <div className="p-6 text-white">
              <p className="text-lg font-medium">AI-powered platform with ASL support</p>
              <p className="text-sm opacity-80">Integrated with Workforce Centers & VR funding</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

