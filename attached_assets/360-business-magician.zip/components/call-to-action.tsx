"use client"

import { useState } from "react"
import { Send } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

export default function CallToAction() {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
    vrClient: false,
    ticketToWork: false,
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormState((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value) => {
    setFormState((prev) => ({ ...prev, service: value }))
  }

  const handleCheckboxChange = (name, checked) => {
    setFormState((prev) => ({ ...prev, [name]: checked }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubmitted(true)
      setFormState({
        name: "",
        email: "",
        phone: "",
        service: "",
        message: "",
        vrClient: false,
        ticketToWork: false,
      })
    }, 1500)
  }

  return (
    <section id="contact" className="py-20">
      <div className="container">
        <div className="max-w-4xl mx-auto bg-card rounded-xl shadow-lg overflow-hidden">
          <div className="grid md:grid-cols-2">
            <div className="bg-primary p-8 text-primary-foreground">
              <h2 className="text-3xl font-bold mb-6">Get Started Today</h2>
              <p className="mb-8">
                Take the first step toward employment, self-employment, or business growth with our AI-powered platform
                designed specifically for deaf individuals.
              </p>

              <div className="space-y-6">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center shrink-0">
                    <span className="text-primary-foreground">01</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Free Consultation</h3>
                    <p className="text-primary-foreground/80">
                      Schedule a consultation to discuss your needs and goals.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center shrink-0">
                    <span className="text-primary-foreground">02</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">VR Funding Check</h3>
                    <p className="text-primary-foreground/80">We'll help determine your eligibility for VR funding.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center shrink-0">
                    <span className="text-primary-foreground">03</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Platform Access</h3>
                    <p className="text-primary-foreground/80">
                      Get access to our AI-powered platform and start your journey.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-8">
              <h3 className="text-2xl font-semibold mb-6">Contact Us</h3>

              {isSubmitted ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
                  <h4 className="text-xl font-medium text-green-800 mb-2">Thank You!</h4>
                  <p className="text-green-700">
                    We've received your message and will contact you shortly to discuss how our AI-powered platform can
                    help with your career or business goals.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formState.name}
                      onChange={handleChange}
                      placeholder="Your full name"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formState.email}
                      onChange={handleChange}
                      placeholder="Your email address"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formState.phone}
                      onChange={handleChange}
                      placeholder="Your phone number"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="service">Service Interested In</Label>
                    <Select value={formState.service} onValueChange={handleSelectChange}>
                      <SelectTrigger id="service">
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="job-seeker">Job Seeker Services</SelectItem>
                        <SelectItem value="self-employment">Self-Employment Assistance</SelectItem>
                        <SelectItem value="small-business">Small Business Services</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center space-x-2 mb-2">
                      <Checkbox
                        id="vr-client"
                        checked={formState.vrClient}
                        onCheckedChange={(checked) => handleCheckboxChange("vrClient", checked)}
                      />
                      <Label htmlFor="vr-client" className="text-sm font-normal">
                        I am a Vocational Rehabilitation client
                      </Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="ticket-to-work"
                        checked={formState.ticketToWork}
                        onCheckedChange={(checked) => handleCheckboxChange("ticketToWork", checked)}
                      />
                      <Label htmlFor="ticket-to-work" className="text-sm font-normal">
                        I am part of the Ticket to Work program
                      </Label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formState.message}
                      onChange={handleChange}
                      placeholder="Tell us about your needs and goals"
                      rows={4}
                    />
                  </div>

                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full" />
                        Sending...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        Send Message
                        <Send className="h-4 w-4" />
                      </span>
                    )}
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

