"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Bot, Send, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

interface VuriAssistantProps {
  onClose: () => void
}

interface Message {
  id: number
  text: string
  sender: "user" | "vuri"
  options?: { text: string; action: string }[]
}

export default function VuriAssistant({ onClose }: VuriAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hi, I'm Vuri, your AI assistant. How can I help you today?",
      sender: "vuri",
      options: [
        { text: "Find VR funding options", action: "funding" },
        { text: "Connect with a VR office", action: "connect" },
        { text: "Learn about 360 Business Magician", action: "learn" },
        { text: "Explore MBTQ Universe", action: "mbtq" },
      ],
    },
  ])
  const [input, setInput] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = () => {
    if (input.trim() === "") return

    // Add user message
    const userMessage: Message = {
      id: messages.length + 1,
      text: input,
      sender: "user",
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")

    // Simulate AI response
    setTimeout(() => {
      let response: Message

      if (
        input.toLowerCase().includes("vr") ||
        input.toLowerCase().includes("funding") ||
        input.toLowerCase().includes("vocational")
      ) {
        response = {
          id: messages.length + 2,
          text: "I can help you with VR funding information. Would you like to learn about what VR covers or how to apply for funding?",
          sender: "vuri",
          options: [
            { text: "What VR covers", action: "vr-covers" },
            { text: "How to apply", action: "vr-apply" },
            { text: "Find nearest VR office", action: "vr-office" },
          ],
        }
      } else if (
        input.toLowerCase().includes("job") ||
        input.toLowerCase().includes("employment") ||
        input.toLowerCase().includes("work")
      ) {
        response = {
          id: messages.length + 2,
          text: "I can help you with job seeking resources. Are you looking for employment assistance or self-employment support?",
          sender: "vuri",
          options: [
            { text: "Employment assistance", action: "employment" },
            { text: "Self-employment support", action: "self-employment" },
            { text: "Small business resources", action: "business" },
          ],
        }
      } else if (input.toLowerCase().includes("mbtq") || input.toLowerCase().includes("universe")) {
        response = {
          id: messages.length + 2,
          text: "MBTQ Universe offers additional solutions beyond what 360 Business Magician provides. Would you like to learn more or visit their platform?",
          sender: "vuri",
          options: [
            { text: "Learn more about MBTQ Universe", action: "mbtq-learn" },
            { text: "Visit MBTQ Universe", action: "mbtq-visit" },
          ],
        }
      } else {
        response = {
          id: messages.length + 2,
          text: "I'm here to help you navigate resources for deaf individuals. What specific area are you interested in?",
          sender: "vuri",
          options: [
            { text: "VR funding", action: "funding" },
            { text: "Employment services", action: "employment" },
            { text: "Self-employment", action: "self-employment" },
            { text: "Small business", action: "business" },
          ],
        }
      }

      setMessages((prev) => [...prev, response])
    }, 1000)
  }

  const handleOptionClick = (action: string) => {
    let response: Message

    switch (action) {
      case "funding":
        response = {
          id: messages.length + 1,
          text: "VR funding can cover various services for deaf individuals. Would you like to learn about specific funding categories?",
          sender: "vuri",
          options: [
            { text: "Job seeker funding", action: "funding-job" },
            { text: "Self-employment funding", action: "funding-self" },
            { text: "Small business funding", action: "funding-business" },
          ],
        }
        break

      case "connect":
        response = {
          id: messages.length + 1,
          text: "I can help you connect with a Vocational Rehabilitation office. Would you like to find the nearest office or submit an inquiry?",
          sender: "vuri",
          options: [
            { text: "Find nearest office", action: "office-find" },
            { text: "Submit inquiry", action: "office-inquiry" },
          ],
        }
        break

      case "learn":
        response = {
          id: messages.length + 1,
          text: "360 Business Magician is an AI-powered platform designed specifically for deaf individuals seeking employment, self-employment, and business growth. What would you like to learn about?",
          sender: "vuri",
          options: [
            { text: "Services offered", action: "learn-services" },
            { text: "Subscription tiers", action: "learn-tiers" },
            { text: "VR funding integration", action: "learn-funding" },
          ],
        }
        break

      case "mbtq":
        response = {
          id: messages.length + 1,
          text: "MBTQ Universe offers complementary services to 360 Business Magician. Would you like to explore their platform for additional solutions?",
          sender: "vuri",
          options: [
            { text: "Visit MBTQ Universe", action: "mbtq-visit" },
            { text: "Compare services", action: "mbtq-compare" },
          ],
        }
        break

      case "office-find":
        response = {
          id: messages.length + 1,
          text: "I can help you find the nearest Vocational Rehabilitation office. Please use our Office Locator tool to find offices in your area.",
          sender: "vuri",
          options: [{ text: "Open Office Locator", action: "open-locator" }],
        }
        break

      case "mbtq-visit":
        response = {
          id: messages.length + 1,
          text: "I'll redirect you to MBTQ Universe where you can find additional solutions for your needs. Would you like to proceed?",
          sender: "vuri",
          options: [
            { text: "Yes, visit MBTQ Universe", action: "redirect-mbtq" },
            { text: "No, stay here", action: "stay" },
          ],
        }
        break

      default:
        response = {
          id: messages.length + 1,
          text: "I can provide more information about that. Is there anything specific you'd like to know?",
          sender: "vuri",
          options: [{ text: "Return to main menu", action: "main-menu" }],
        }
    }

    setMessages((prev) => [...prev, response])
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSend()
    }
  }

  return (
    <div className="flex flex-col h-[500px] max-h-[80vh]">
      <div className="flex items-center justify-between p-4 bg-primary text-primary-foreground">
        <div className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          <h3 className="font-semibold">Vuri AI Assistant</h3>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="text-primary-foreground">
          <X className="h-5 w-5" />
          <span className="sr-only">Close</span>
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.sender === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
              }`}
            >
              <p>{message.text}</p>

              {message.options && (
                <div className="mt-3 flex flex-col gap-2">
                  {message.options.map((option, index) => (
                    <Button
                      key={index}
                      variant={message.sender === "user" ? "secondary" : "outline"}
                      size="sm"
                      className="justify-start"
                      onClick={() => handleOptionClick(option.action)}
                    >
                      {option.text}
                    </Button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <Separator />

      <div className="p-4">
        <div className="flex gap-2">
          <Input
            placeholder="Type your question..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1"
          />
          <Button onClick={handleSend} disabled={input.trim() === ""}>
            <Send className="h-4 w-4" />
            <span className="sr-only">Send</span>
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Vuri can help with VR funding, office locations, and redirect to MBTQ Universe for additional solutions.
        </p>
      </div>
    </div>
  )
}

