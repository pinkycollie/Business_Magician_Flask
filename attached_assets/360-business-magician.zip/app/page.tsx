import Header from "@/components/header"
import Hero from "@/components/hero"
import Services from "@/components/services"
import FundingInfo from "@/components/funding-info"
import VrRequestGuide from "@/components/vr-request-guide"
import SubscriptionTiers from "@/components/subscription-tiers"
import TechStack from "@/components/tech-stack"
import Features from "@/components/features"
import Testimonials from "@/components/testimonials"
import CallToAction from "@/components/call-to-action"
import Footer from "@/components/footer"
import AccessibilityWidget from "@/components/accessibility-widget/accessibility-widget"
import Sponsors from "@/components/sponsors"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <Services />
        <FundingInfo />
        <VrRequestGuide />
        <SubscriptionTiers />
        <TechStack />
        <Features />
        <Testimonials />
        <Sponsors />
        <CallToAction />
      </main>
      <Footer />
      <AccessibilityWidget />
    </div>
  )
}

